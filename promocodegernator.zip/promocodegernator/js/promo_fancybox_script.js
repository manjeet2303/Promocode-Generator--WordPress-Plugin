jQuery(document).ready(function()
{
  var modal1= '<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"><div class="modal-dialog modal-sm"><div class="modal-content"></div></div></div>';
  
  jQuery('body').append(modal1);
});